package com;

import com.controller.AppointmentController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Appointment;
import com.model.Doctor;
import com.model.Patient;
import com.repository.AppointmentRepository;
import com.repository.DoctorRepository;
import com.repository.PatientRepository;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(AppointmentController.class)
public class AppointmentControllerTests {

    @MockBean
    AppointmentRepository appointmentRepository;
    @MockBean
    DoctorRepository doctorRepository;
    @MockBean
    PatientRepository patientRepository;
    @Autowired
    MockMvc mockMvc;

    @Test
    public void testGetAppointments() throws Exception {
        String date_str = "2022-09-18 10:20:00";
        DateFormat date_formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = date_formatter.parse(date_str);

        Appointment appointment = new Appointment(1, 1, 1, date);
        List<Appointment> appointments = Arrays.asList(appointment);

        Mockito.when(appointmentRepository.findAll()).thenReturn(appointments);

        mockMvc.perform(get("/appointment/appointments")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].id", Matchers.is(1)));

    }

    @Test
    public void testGetAppointment() throws Exception {
        Date date = new Date();
        Appointment appointment = new Appointment(2, 1, 1, date);

        Mockito.when(appointmentRepository.findById(2L)).thenReturn(java.util.Optional.of(appointment));

        mockMvc.perform(get("/appointment/{id}", 2))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", Matchers.is(2)));

    }

    @Test
    public void testCreateAppointment() throws Exception {
        Date date = new Date();
        Appointment appointment = new Appointment(3, 1, 1, date);

        Mockito.when(appointmentRepository.save(appointment)).thenReturn(appointment);

        mockMvc.perform(post("/appointment/appointment")
                        .content(asJsonString(appointment))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
    }

    @Test
    public void testGetDoctors() throws Exception {
        Doctor doctor = new Doctor(2, "Doc1", "LastName", null, null);
        List<Doctor> doctors = Arrays.asList(doctor);

        Mockito.when(doctorRepository.findAll()).thenReturn(doctors);

        mockMvc.perform(get("/appointment/doctors")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].id", Matchers.is(2)));
    }


    @Test
    public void testGetDoctorBy() throws Exception {
        Doctor doctor = new Doctor(2, "Doc1", "LastName", null, null);

        Mockito.when(doctorRepository.findById(2L)).thenReturn(java.util.Optional.of(doctor));

        mockMvc.perform(get("/appointment/doctor/{id}", 2))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", Matchers.is(2)));
    }

    @Test
    public void testGetPatient() throws Exception {
        Patient patient = new Patient(1, "Patient1", "LastName", null, null, null);
        List<Patient> patients = Arrays.asList(patient);

        Mockito.when(patientRepository.findAll()).thenReturn(patients);

        mockMvc.perform(get("/appointment/patients")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].id", Matchers.is(1)));
    }


    @Test
    public void testGetPatientBy() throws Exception {
        Patient patient = new Patient(2, "Patient1", "LastName", null, null, null);

        Mockito.when(patientRepository.findById(2L)).thenReturn(java.util.Optional.of(patient));

        mockMvc.perform(get("/appointment/patient/{id}", 2))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", Matchers.is(2)));
    }

    static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}





