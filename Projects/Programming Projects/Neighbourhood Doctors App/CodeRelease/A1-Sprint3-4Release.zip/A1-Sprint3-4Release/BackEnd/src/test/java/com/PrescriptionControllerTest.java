package com;

import com.controller.PrescriptionController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Prescription;
import com.repository.PatientRepository;
import com.repository.PrescriptionRepository;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.List;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(PrescriptionController.class)
public class PrescriptionControllerTest {

    @MockBean
    PrescriptionRepository prescriptionRepository;
    @MockBean
    PatientRepository patientRepository;
    @Autowired
    MockMvc mockMvc;

    @Test
    public void testGetAllPrescriptions() throws Exception {
        Prescription prescription = new Prescription(2, "medicine", 1, 2, "detailed description");
        List<Prescription> prescriptions = Arrays.asList(prescription);

        Mockito.when(prescriptionRepository.findAll()).thenReturn(prescriptions);

        mockMvc.perform(get("/prescription/prescriptions")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].doctorId", Matchers.is(1)));
    }

    @Test
    public void testGetPrescription() throws Exception {
        Prescription prescription = new Prescription(2, "medicine", 1, 2, "detailed description");

        Mockito.when(prescriptionRepository.findById(2L)).thenReturn(java.util.Optional.of(prescription));

        mockMvc.perform(get("/prescription/{prescriptionID}", 2))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", Matchers.is(2)));
    }
    @Test
    public void testGetPrescriptionPatientId() throws Exception {
        Prescription prescription = new Prescription(2, "medicine", 1, 2, "detailed description");
        List<Prescription> prescriptions = Arrays.asList(prescription);

        Mockito.when(prescriptionRepository.findByPatientId(2L)).thenReturn(prescriptions);

        mockMvc.perform(get("/prescription/{patientID}/prescriptions", 2))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].id", Matchers.is(2)));
    }


    @Test
    public void testCreatePrescription() throws Exception {
        Prescription prescription = new Prescription(2, "medicine", 1, 2, "detailed description");


        Mockito.when(prescriptionRepository.save(prescription)).thenReturn(prescription);

        mockMvc.perform(post("/prescription/prescription")
                        .content(asJsonString(prescription))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
    }

    static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
