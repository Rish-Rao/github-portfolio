package com.controller;

import com.repository.AccountRepository;
import com.security.JwtAuthentication;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.exceptions.BasicErrorResponse;
import com.model.Account;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin()
@RequestMapping(path = "/account")
public class AccountController {

    @Autowired
    private AccountRepository accountRepository;

    @GetMapping(path = "/accounts")
    public List<Account> getDoctors() {
        return accountRepository.findAll();
    }

    /**
     * Returns account by account id
     * @param id
     * @return
     */
    @GetMapping(path = "/{id}")
    public Optional<Account> getAccountDetails(@PathVariable Long id) {
        return accountRepository.findById(id);
    }

    /**
     * Returns account when token is valid
     * @param token
     * @return
     */
    @GetMapping(path = "/")
    public ResponseEntity<?> getAuthAccountDetails(@RequestHeader(name="Authorization") String token) {
        // Check authication
        DecodedJWT jwt = new JwtAuthentication().validateToken(token);
        if (jwt == null) {
            return new ResponseEntity<>(new BasicErrorResponse("Invalid or missing token"), HttpStatus.UNAUTHORIZED);
        }

        // Get account
        long id = Long.parseLong(jwt.getSubject());
        Optional<Account> account = accountRepository.findById(id);
        return new ResponseEntity<>(account, HttpStatus.OK);
    }

    /**
     * Creates a new account by taking account jason as input
     * @param account
     * @return
     */
    @PostMapping(path = "/account")
    public ResponseEntity<Account> addAccount(@RequestBody Account account) {
        Account createAccount = accountRepository
                .save(Account.builder()
                        .email(account.getEmail())
                        .passwordHash(account.getPasswordHash())
                        .userType(account.getUserType())
                        .build());

        return new ResponseEntity<>(createAccount, HttpStatus.CREATED);
    }

    /**
     * Deletes account by taking account id as input
     * @param id
     * @return
     */
    @DeleteMapping(path = "/{id}")
    public String deleteAccount(@PathVariable Long id) {
        accountRepository.deleteById(id);
        return "Account deleted Success!";
    }
}