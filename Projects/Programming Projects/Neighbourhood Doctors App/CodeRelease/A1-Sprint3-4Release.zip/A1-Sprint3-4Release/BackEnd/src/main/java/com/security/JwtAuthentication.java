package com.security;

import java.time.Instant;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

public class JwtAuthentication {

    private static final String SECRET = "your_jwt_secret";
    private static final String ISSUER = "NeighborhoodDoctors";

    public DecodedJWT validateToken(String token) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(SECRET);
            JWTVerifier verifier = JWT.require(algorithm).withIssuer(ISSUER).acceptExpiresAt(10).build();
            return verifier.verify(token);
        } catch (Exception e) {
            return null;
        }
    }

    public static String GenerateToken(String subject) {
        Algorithm algorithm = Algorithm.HMAC256(SECRET);
        return JWT.create().withIssuer(ISSUER).withSubject(subject).withExpiresAt(Instant.now().plusSeconds(31536000)).sign(algorithm);
    }
}
