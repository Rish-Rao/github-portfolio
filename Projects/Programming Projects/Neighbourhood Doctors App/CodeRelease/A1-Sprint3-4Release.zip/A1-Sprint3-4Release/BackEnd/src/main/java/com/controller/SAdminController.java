package com.controller;

import com.model.Account;
import com.model.Doctor;
import com.repository.AccountRepository;
import com.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@CrossOrigin()
@RestController
@RequestMapping(path = "/sAdmin")
public class SAdminController {
    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AccountRepository accountRepository;

    /**
     * Return doctors list
     * @return
     */
    @GetMapping(path = "/doctors")
    public ResponseEntity<List<Doctor>> getDoctors() {
        try {
            return new ResponseEntity<>(doctorRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Returns account id as Long by taking in doctors id as input
     * @param id
     * @return
     */
    @GetMapping(path = "/doctor/account/{id}")
    public ResponseEntity<Long> getDoctorsAccountId(@PathVariable("id") long id) {
        try {
            //check if teacher exist in database
            Doctor doctorObj = getDoctorRec(id);

            // Returning data
            if (doctorObj != null) {
                return new ResponseEntity<>(doctorObj.getAccount().getId(), HttpStatus.OK);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Deletes doctor by taking in id as input
     * @param id
     * @return
     */
    @DeleteMapping(path = "/doctor/{id}")
    public ResponseEntity<HttpStatus> deleteDoctorById(@PathVariable("id") long id) {
        try {

            //check if Doctor exist in database
            Doctor doctorObj = getDoctorRec(id);

            if (doctorObj != null) {
                doctorRepository.deleteById(id);
                return new ResponseEntity<>(HttpStatus.ACCEPTED);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Updates doctor in the database by taking in id and doctor json as input
     * @param id
     * @param doctor
     * @return
     */
    @PutMapping("/doctor/{id}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable("id") long id, @RequestBody Doctor doctor) {

        //check if Doctor exist in database
        Doctor doctorObj = getDoctorRec(id);

        if (doctorObj != null) {
            doctorObj.setFirstName(doctor.getFirstName());
            doctorObj.setLastName(doctor.getLastName());
            return new ResponseEntity<>(doctorRepository.save(doctorObj), HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Updates account in the database by taking in id and account json as input
     * @param id
     * @param account
     * @return
     */
    @PutMapping("/account/{id}")
    public ResponseEntity<Account> updateAccount(@PathVariable("id") long id, @RequestBody Account account) {

        //check if Doctor exist in database
        Account accountObj = getAccountRec(id);

        if (accountObj != null) {
            accountObj.setEmail(account.getEmail());
            accountObj.setPasswordHash(account.getPasswordHash());
            return new ResponseEntity<>(accountRepository.save(accountObj), HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Creates a new account
     * @param account
     * @return
     */
    @PostMapping(path = "/account")
    public ResponseEntity<Long> createAccount(@RequestBody Account account) {
        Account createAccount = accountRepository
                .save(Account.builder()
                        .email(account.getEmail())
                        .passwordHash(account.getPasswordHash())
                        .userType(account.getUserType())
                        .build());

        return new ResponseEntity<>(createAccount.getId(), HttpStatus.CREATED);
    }

    /**
     * Creates a new doctor by taking in account id as input and doctors json
     * @param id
     * @param doctor
     * @return
     */
    @PostMapping(path = "/doctor/{id}")
    public ResponseEntity<Doctor> createDoctor(@PathVariable("id") long id, @RequestBody Doctor doctor) {

        //check if Doctor exist in database
        Account accountObj = getAccountRec(id);

        // If account does not exist returns notfound
        if(accountObj == null ) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        Doctor createDoctor = doctorRepository
                .save(Doctor.builder()
                        .firstName(doctor.getFirstName())
                        .lastName(doctor.getLastName())
                        .account(accountObj)
                        .build());

        return new ResponseEntity<>(createDoctor, HttpStatus.CREATED);
    }

    /**
     * returns doctors record if it exists in database by taking id as input
     * @param id
     * @return doctor object
     */
    private Doctor getDoctorRec(long id) {
        Optional<Doctor> doctorObj = doctorRepository.findById(id);

        if (doctorObj.isPresent()) {
            return doctorObj.get();
        }
        return null;
    }

    /**
     * returns account record if it exists in database by taking id as input
     * @param id
     * @return doctor object
     */
    private Account getAccountRec(long id) {
        Optional<Account> accountObj = accountRepository.findById(id);

        if (accountObj.isPresent()) {
            return accountObj.get();
        }
        return null;
    }
}

