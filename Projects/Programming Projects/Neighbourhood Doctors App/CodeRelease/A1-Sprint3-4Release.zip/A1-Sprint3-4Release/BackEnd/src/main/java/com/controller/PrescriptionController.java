package com.controller;

import com.repository.*;
import com.model.*;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin()
@RestController
@RequestMapping("/prescription")
public class PrescriptionController {

    @Autowired
    private PrescriptionRepository prescriptionRepository;

    @Autowired
    private PatientRepository patientRepository;

    /**
     * Return prescriptions list
     * @return
     */
    @GetMapping(path = "/prescriptions")
    public ResponseEntity<List<Prescription>> getAllPrescriptions() {
        try {
            return new ResponseEntity<>(prescriptionRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Return prescription by taking prescription id as input
     * @param prescriptionID
     * @return
     */
    @GetMapping(path = "/{prescriptionID}")
    public ResponseEntity<Prescription> getPrescription(@PathVariable Long prescriptionID) {
        try {
            // check if prescription exist in database
            Prescription prescriptionObj = getPrescriptionRecord(prescriptionID);

            if (prescriptionObj != null) {
                return new ResponseEntity<>(prescriptionObj, HttpStatus.OK);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Returns prescription by taking in patients id as input
     * @param patientID
     * @return
     */
    @GetMapping(path = "/{patientID}/prescriptions")
    public ResponseEntity<List<Prescription>> getPrescriptions(@PathVariable Long patientID) {
        try {
            return new ResponseEntity<>(prescriptionRepository.findByPatientId(patientID), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Creates a new prescription by taking in prescription json
     * @param prescription
     * @return
     */
    @PostMapping(path = "/prescription")
    public ResponseEntity<Prescription> newPrescription(@RequestBody Prescription prescription) {
        Prescription createPrescription = prescriptionRepository
                .save(Prescription.builder()
                        .medicationName(prescription.getMedicationName())
                        .doctorId(prescription.getDoctorId())
                        .patientId(prescription.getPatientId())
                        .description(prescription.getDescription())
                        .build());

        return new ResponseEntity<>(createPrescription, HttpStatus.CREATED);
    }


    /**
     * Deletes prescription by taking prescription id as input
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<List<Prescription>> deletePrescription(@PathVariable Long id) {

        try {
            // check if prescription exist in database
            Prescription pr = getPrescriptionRecord(id);

            if (pr != null) {
                prescriptionRepository.deleteById(id);
                return new ResponseEntity<>(null, HttpStatus.OK);
            }

            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * returns prescription record if it exists in database by taking id as input
     * @param id
     * @return
     */
    private Prescription getPrescriptionRecord(long id) {
        Optional<Prescription> prescriptionObj = prescriptionRepository.findById(id);

        if (prescriptionObj.isPresent()) {
            return prescriptionObj.get();
        }
        return null;
    }

}