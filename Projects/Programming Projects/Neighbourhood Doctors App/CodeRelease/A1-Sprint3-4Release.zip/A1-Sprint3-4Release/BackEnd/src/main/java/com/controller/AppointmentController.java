package com.controller;

import com.model.Appointment;
import com.model.Doctor;
import com.model.Patient;
import com.repository.AppointmentRepository;
import com.repository.DoctorRepository;
import com.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin()
@RequestMapping(path = "/appointment")
public class AppointmentController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private PatientRepository patientRepository;

    /**
     * Returns list of all appointments
     * @return
     */
    @GetMapping(path = "/appointments")
    public ResponseEntity<List<Appointment>> getAppointments() {
        try {
            return new ResponseEntity<>(appointmentRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Returns appointment by appointment id
     * @param id
     * @return
     */
    @GetMapping(path = "/{id}")
    public Appointment getAppointmentsDetails(@PathVariable Long id) {

        Optional<Appointment> ap = appointmentRepository.findById(id);
        if (ap.isPresent()) {
            return ap.get();
        }
        return null;
    }

    /**
     * Creates a new appointment by taking appointment json as input
     * @param appointment
     * @return
     */
    @PostMapping(path = "/appointment")
    public ResponseEntity<Appointment> createAppointment(@RequestBody Appointment appointment) {
        Appointment createAppointment = appointmentRepository
                .save(Appointment.builder()
                        .doctorsId(appointment.getDoctorsId())
                        .patientsId(appointment.getPatientsId())
                        .date(appointment.getDate())
                        .build());

        return new ResponseEntity<>(createAppointment, HttpStatus.CREATED);
    }

    /**
     * Deletes appointment by using its id
     * @param id
     * @return
     */
    @DeleteMapping(path = "/{id}")
    public ResponseEntity<List<Appointment>> deleteAppointment(@PathVariable Long id) {
        try {
            Appointment ap = getAppointmentsDetails(id);

            if (ap != null) {
                appointmentRepository.deleteById(id);
                return new ResponseEntity<>(null, HttpStatus.OK);
            }
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Return doctors list
     * @return
     */
    @GetMapping(path = "/doctors")
    public ResponseEntity<List<Doctor>> getDoctors() {
        try {
            return new ResponseEntity<>(doctorRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Returns doctor object by taking id as input
     * @param id
     * @return
     */
    @GetMapping(path = "/doctor/{id}")
    public ResponseEntity<Doctor> getDoctor(@PathVariable("id") long id) {
        try {
            //check if Doctor exist in database
            Doctor doctorObj = getDoctorRec(id);

            // Returning data
            if (doctorObj != null) {
                return new ResponseEntity<>(doctorObj, HttpStatus.OK);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Return patients list
     * @return
     */
    @GetMapping(path = "/patients")
    public ResponseEntity<List<Patient>> getPatients() {
        try {
            return new ResponseEntity<>(patientRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Returns patient object by taking id as input
     * @param id
     * @return
     */
    @GetMapping(path = "/patient/{id}")
    public ResponseEntity<Patient> getPatient(@PathVariable("id") long id) {
        try {
            //check if Patient exist in database
            Patient patientObj = getPatientRec(id);

            // Returning data
            if (patientObj != null) {
                return new ResponseEntity<>(patientObj, HttpStatus.OK);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * returns doctors record if it exists in database by taking id as input
     * @param id
     * @return doctor object
     */
    private Doctor getDoctorRec(long id) {
        Optional<Doctor> doctorObj = doctorRepository.findById(id);

        if (doctorObj.isPresent()) {
            return doctorObj.get();
        }
        return null;
    }

    /**
     * returns patient record if it exists in database by taking id as input
     * @param id
     * @return patient object
     */
    private Patient getPatientRec(long id) {
        Optional<Patient> patientObj = patientRepository.findById(id);

        if (patientObj.isPresent()) {
            return patientObj.get();
        }
        return null;
    }
}
