package com;

import com.controller.SAdminController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Account;
import com.model.Doctor;
import com.repository.AccountRepository;
import com.repository.DoctorRepository;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.List;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(SAdminController.class)
public class SAdminControllerTests {

    @MockBean
    DoctorRepository doctorRepository;
    @MockBean
    AccountRepository accountRepository;
    @Autowired
    MockMvc mockMvc;

    @Test
    public void getDoctors() throws Exception {
        Doctor doctor = new Doctor(2, "Doc1", "LastName", null, null);
        List<Doctor> doctors = Arrays.asList(doctor);

        Mockito.when(doctorRepository.findAll()).thenReturn(doctors);

        mockMvc.perform(get("/sAdmin/doctors")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].id", Matchers.is(2)));
    }

    @Test
    public void getDoctorsAccountId() throws Exception {
        Account account = new Account(1, "doc@doc.com", "password", "doctor");
        Doctor doctor = new Doctor(2, "Doc1", "LastName", null, account);

        Mockito.when(doctorRepository.findById(2L)).thenReturn(java.util.Optional.of(doctor));

        mockMvc.perform(get("/sAdmin/doctor/account/{id}", 2)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.is(1)));
    }

    @Test
    public void testUpdateAccount() throws Exception {
        Account account = new Account(1, "doc@doc.com", "password", "doctor");
        Account account2 = new Account(1, "doc222@doc.com", "password", "doctor");

        Mockito.when(accountRepository.findById(1L)).thenReturn(java.util.Optional.of(account));
        Mockito.when(accountRepository.save(account2)).thenReturn(account2);


        mockMvc.perform(put("/sAdmin/account/{id}", 1)
                        .content(asJsonString(account2))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    public void testCreateDoctor() throws Exception {
        Account account = new Account(1, "doc@doc.com", "password", "doctor");
        Doctor doctor = new Doctor(2, "Doc1", "LastName", null, account);

        Mockito.when(accountRepository.findById(1L)).thenReturn(java.util.Optional.of(account));
        Mockito.when(doctorRepository.save(doctor)).thenReturn(doctor);


        mockMvc.perform(post("/sAdmin/doctor/{id}", 1)
                        .content(asJsonString(doctor))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
    }



    static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
