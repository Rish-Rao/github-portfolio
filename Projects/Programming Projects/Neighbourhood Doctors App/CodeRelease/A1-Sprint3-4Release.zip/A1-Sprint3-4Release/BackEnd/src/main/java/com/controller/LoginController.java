package com.controller;

import com.security.JwtAuthentication;
import com.exceptions.BasicErrorResponse;
import com.model.Account;
import com.model.Doctor;
import com.model.Patient;
import com.payload.LoginRequest;
import com.payload.LoginSuccessResponse;
import com.repository.AccountRepository;
import com.repository.DoctorRepository;
import com.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin()
@RequestMapping(path = "/login")
public class LoginController {

    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private PatientRepository patientRepository;

    /**
     * Logins specific user based on account type
     * @param loginRequest
     * @return
     */
    @PostMapping(path = "/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        try {
            // Find user account by email
            Patient patient = patientRepository.findAll().stream().filter(p -> p.getAccount().getEmail().equals(loginRequest.getEmail())).findFirst().orElse(null);
            Doctor doctor = doctorRepository.findAll().stream().filter(p -> p.getAccount().getEmail().equals(loginRequest.getEmail())).findFirst().orElse(null);

            // Check if both accounts match, this should never happen
            if (patient != null && doctor != null && patient.getAccount().getId() != doctor.getAccount().getId()) {
                return new ResponseEntity<>(new BasicErrorResponse("Account mismatch, contact system admin!"), HttpStatus.INTERNAL_SERVER_ERROR);
            }

            // Get account (doctor preferred)
            Account account = doctor != null ? doctor.getAccount() : patient != null ? patient.getAccount() : null;

            // Check if account exists
            if (account == null) {
                return new ResponseEntity<>(new BasicErrorResponse("Account not found"), HttpStatus.NOT_FOUND);
            }

            Argon2PasswordEncoder encoder = new Argon2PasswordEncoder();

            // Check if password is hashed, this is to enure alll passwords are hashed
            if (!account.getPasswordHash().startsWith("$argon2id$")) {
                account.setPasswordHash(encoder.encode(account.getPasswordHash()));
                accountRepository.save(account);
            }

            // Check password
            if (encoder.matches(loginRequest.getPassword(), account.getPasswordHash())) {
                // Generate JWT with the account ID as the subject
                String token = JwtAuthentication.GenerateToken(account.getId().toString());
                return new ResponseEntity<>(new LoginSuccessResponse(token, doctor, patient), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new BasicErrorResponse("Incorrect password"), HttpStatus.UNAUTHORIZED);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
