package com.exceptions;

public class InvalidLoginResponse {

    private String email;
    private String passwordHash;

    public InvalidLoginResponse() {
        this.email = "Invalid Email";
        this.passwordHash = "Invalid Password";
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
}

