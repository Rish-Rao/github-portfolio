package com.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column
    private long patientsId;
    @Column
    private long doctorsId;
    @DateTimeFormat
    private Date date;

    public long getPatientsId() {
        return patientsId;
    }

    public void setPatientsId(long patientsId) {
        this.patientsId = patientsId;
    }

    public long getDoctorsId() {
        return doctorsId;
    }

    public void setDoctor(long doctorsId) {
        this.doctorsId = doctorsId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
