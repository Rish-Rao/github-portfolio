package com.controller;

import com.model.Account;
import com.model.Patient;
import com.repository.AccountRepository;
import com.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin()
@RestController
@RequestMapping(path = "/register")
public class RegisterController {
    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private AccountRepository accountRepository;

    /**
     * Return patients list
     * @return
     */
    @GetMapping(path = "/patients")
    public ResponseEntity<List<Patient>> getPatient() {
        try {
            return new ResponseEntity<>(patientRepository.findAll(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Returns account id as Long by taking in patient id as input
     * @param id
     * @return
     */
    @GetMapping(path = "/patient/account/{id}")
    public ResponseEntity<Long> getPatientsAccountId(@PathVariable("id") long id) {
        try {
            //check if patient exist in database
            Patient patientObj = getPatientRec(id);

            // Returning data
            if (patientObj != null) {
                return new ResponseEntity<>(patientObj.getAccount().getId(), HttpStatus.OK);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Deletes patient by taking in id as input
     * @param id
     * @return
     */
    @DeleteMapping(path = "/patient/{id}")
    public ResponseEntity<HttpStatus> deletePatientById(@PathVariable("id") long id) {
        try {

            //check if patient exist in database
            Patient patientObj = getPatientRec(id);

            if (patientObj != null) {
                patientRepository.deleteById(id);
                return new ResponseEntity<>(HttpStatus.OK);
            }

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Updates patient in the database by taking in id and patient json as input
     * @param id
     * @param patient
     * @return
     */
    @PutMapping("/patient/{id}")
    public ResponseEntity<Patient> updatePatient(@PathVariable("id") long id, @RequestBody Patient patient) {

        //check if patient exist in database
        Patient patientObj = getPatientRec(id);

        if (patientObj != null) {
            patientObj.setFirstName(patient.getFirstName());
            patientObj.setLastName(patient.getLastName());
            return new ResponseEntity<>(patientRepository.save(patientObj), HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Updates account in the database by taking in id and account json as input
     * @param id
     * @param account
     * @return
     */
    @PutMapping("/account/{id}")
    public ResponseEntity<Account> updateAccount(@PathVariable("id") long id, @RequestBody Account account) {

        //check if Doctor exist in database
        Account accountObj = getAccountRec(id);

        if (accountObj != null) {
            accountObj.setEmail(account.getEmail());
            accountObj.setPasswordHash(account.getPasswordHash());
            return new ResponseEntity<>(accountRepository.save(accountObj), HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Creates a new patient by taking in account id as input and doctors json
     * @param id
     * @param patient
     * @return
     */
    @PostMapping(path = "/patient/{id}")
    public ResponseEntity<Patient> createAccount(@PathVariable("id") long id, @RequestBody Patient patient) {

        //check if patient exist in database
        Account accountObj = getAccountRec(id);

        // If account does not exist returns notfound
        if(accountObj == null ) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        Patient createPatient = patientRepository
                .save(Patient.builder()
                        .firstName(patient.getFirstName())
                        .lastName(patient.getLastName())
                        .account(accountObj)
                        .build());

        return new ResponseEntity<>(createPatient, HttpStatus.CREATED);
    }

    /**
     * returns patient record if it exists in database by taking id as input
     * @param id
     * @return doctor object
     */
    private Patient getPatientRec(long id) {
        Optional<Patient> patientObj = patientRepository.findById(id);

        if (patientObj.isPresent()) {
            return patientObj.get();
        }
        return null;
    }

    /**
     * returns account record if it exists in database by taking id as input
     * @param id
     * @return doctor object
     */
    private Account getAccountRec(long id) {
        Optional<Account> accountObj = accountRepository.findById(id);

        if (accountObj.isPresent()) {
            return accountObj.get();
        }
        return null;
    }
}