package com.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class Prescription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column
    private String medicationName;
    @Column
    private long doctorId;
    @Column
    private long patientId;
    @Column
    private String description;


    public void setMedicationName(String medicationName) {
        this.medicationName = medicationName;
    }

    public String getMedicationName() {
        return medicationName;
    }

    public long getId() {
        return id;
    }

    public long getPatientId() {
      return patientId;
    }

    public void setPatientId(long patientId) {
      this.patientId = patientId;
    }  

    public void setDoctorId(long doctorId) {
      this.doctorId = doctorId;
    }

    public long getDoctorId() {
      return this.doctorId;
    }

    public void setDescription(String description) {
      this.description = description;
    }

    public String getDescription() {
      return this.description;
    }

}