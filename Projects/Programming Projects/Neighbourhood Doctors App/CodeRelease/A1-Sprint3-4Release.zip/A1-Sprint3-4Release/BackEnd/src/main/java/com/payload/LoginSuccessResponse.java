package com.payload;

import com.model.Doctor;
import com.model.Patient;

public class LoginSuccessResponse {

    private String token;
    private Doctor doctor;
    private Patient patient;

    public LoginSuccessResponse(String token, Doctor doctor, Patient patient) {
        this.token = token;
        this.doctor = doctor;
        this.patient = patient;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }    
}
