package com.exceptions;

public class BasicErrorResponse {

    private String message;

    public BasicErrorResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}