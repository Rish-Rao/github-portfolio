import 'package:flutter/material.dart';
import 'package:neighborhood_doctors/controller/Controllers.dart';
import 'package:neighborhood_doctors/repository/Repositories.dart';

class EditDoctorsSAdminScreen extends StatefulWidget {
  final int doctorsId;
  const EditDoctorsSAdminScreen({required this.doctorsId, super.key});
  
  @override
  State<EditDoctorsSAdminScreen> createState() => EditDoctorsSAdminScreenStateful(doctorsId: doctorsId);

}

class EditDoctorsSAdminScreenStateful extends State<EditDoctorsSAdminScreen> {
  
  final int doctorsId; 

  final _sAdminController = SAdminController(SAdminRepository());
  final _formKey = GlobalKey<FormState>();

  late String _firstName;
  late String _lastName;
  late String _email;
  late String _password;

  EditDoctorsSAdminScreenStateful({required this.doctorsId});

  Widget _buildFirstNameField() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'FirstName'),

      validator: (String? value) {
        if (value!.isEmpty) {
          return "FirstName cannot be empty";
        }
        return null;
      },
      
      onSaved: (String? value) {
        _firstName = value!;
      },

    );
  }

    Widget _buildLastNameField() {
      return TextFormField(
        decoration: InputDecoration(labelText: 'LastName'),

        validator: (String? value) {
          if (value!.isEmpty) {
            return "LastName cannot be empty";
          }
          return null;
        },
        
        onSaved: (String? value) {
          _lastName = value!;
        },

      );
  }

    Widget _buildEmailField() {
      return TextFormField(
        decoration: InputDecoration(labelText: 'Email'),
        keyboardType: TextInputType.emailAddress,

        validator: (String? value) {
          if (value!.isEmpty) {
            return "Email cannot be empty";
          }

          // Email regex
          if (!RegExp(
                r"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
            .hasMatch(value)) {
          return 'Please enter a valid email Address';
          }

          return null;
        },
        
        onSaved: (String? value) {
          _email = value!;
        },

      );
  }

      Widget _buildPasswordField() {
      return TextFormField(
        decoration: InputDecoration(labelText: 'Password'),
        keyboardType: TextInputType.visiblePassword,

        validator: (String? value) {
          if (value!.isEmpty) {
            return "Password is required";
          }

          return null;
        },
        
        onSaved: (String? value) {
          _password = value!;
        },

      );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      
      // App Bar
      appBar: AppBar(
        title: const Text('Edit Doctor'),
      ),


      // Container
      body: Container(

        // Sort of all sides padding 
        margin: EdgeInsets.all(42),

        // Form
        child: Form(
          key: _formKey,
          child: Column(
            
            // Everything in center
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              _buildFirstNameField(),
              _buildLastNameField(),
              SizedBox(height: 20,),
              _buildEmailField(),
              _buildPasswordField(),

              // Button
              SizedBox(height: 40,),
              ElevatedButton(
                child: const Text('Update'),

                // On Click event 
                onPressed: () => {
            
                  if(_formKey.currentState!.validate()) {
                     _formKey.currentState?.save(),
                     putDoctor()
                  } 

                },
              )

            ],

          ),
        )

      ),


    );
  }

  // Edits doctors details 
  Future<void> putDoctor() async {
    // Retrives account id with docs id 
    int accountId = await _sAdminController.getDoctorsAccountId(doctorsId);

    if(accountId > 0 ) {
      // updates doctors details
      _sAdminController.putDoctor(_firstName, _lastName, doctorsId);

      // updates account details 
      _sAdminController.putAccount(_email, _password, accountId);

      // Takes back to doctors list page 
      Navigator.pop(context);
    }
    // ToDO:: can add widgets to show what error occured if any occurs 
    
  }

}