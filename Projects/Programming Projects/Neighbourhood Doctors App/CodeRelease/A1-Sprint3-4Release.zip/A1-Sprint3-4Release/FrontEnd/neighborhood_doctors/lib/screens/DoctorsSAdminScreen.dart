import 'package:flutter/material.dart';
import 'package:neighborhood_doctors/controller/Controllers.dart';
import 'package:neighborhood_doctors/data/Models.dart';
import 'package:neighborhood_doctors/repository/Repositories.dart';
import 'package:neighborhood_doctors/screens/Screens.dart';


class DoctorsSAdminScreen extends StatefulWidget {
  @override
  State<DoctorsSAdminScreen> createState() => _DoctorsSAdminScreenStatefull();
}

class _DoctorsSAdminScreenStatefull extends State<DoctorsSAdminScreen> {
  
  final _sAdminController = SAdminController(SAdminRepository());
  late Future<List<Doctor>> _doctorsList;

  // initial State
  @override
  void initState() {
    super.initState();
    _doctorsList = getData();
  }
  
  // Updates the current list 
  void refreshList() {
    // reload
    setState(() {
      _doctorsList = getData();
    });
  }

  // Gets data from API returns the data 
  Future<List<Doctor>> getData() async {
    await Future.delayed(const Duration(seconds: 1));
    return _sAdminController.fetchDoctorsList();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      // Top of app 
      appBar: AppBar(
        title: const Text('Doctors'),

        // Add circle widget
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: GestureDetector(
              onTap: () {
                addDoc();
              },
              child: const Icon(
                Icons.add_circle_outline_rounded,
                size: 26.0,
              ),
            ),
          ),
        ],

      ),

      // Pull down refresh functionlity
      body: RefreshIndicator(
        onRefresh: () async {
          refreshList();
        },

        // Fetchd data list builder
        child: FutureBuilder<List<Doctor>>(

          future: _doctorsList,
          builder: (context, AsyncSnapshot<List<Doctor>> snapshot) {
            
            // Wait for data inidcator
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }

            // Error msg id no data could be fetched
            if (snapshot.hasError) {
              return const Center(
                child: Text('Could not fetch data'),
              );
            }

            // Displays list in UI 
            return ListView.separated(
              
                itemBuilder: (context, index) {
                  var doctor = snapshot.data?[index];

                  // Main container for each row [-----]
                  return Container(
                      height: 75.0,
                      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),

                      child:

                        // Main Col 
                        Column(children: [

                          // Row 1 for doctors data 
                            Row(children: [
                              Expanded(flex:0, child: Text('${doctor?.firstName}  ${doctor?.lastName}')),
                              
                              // Seprates text to left and right 
                              const Spacer(),

                              Expanded(flex:0, child: Text('${doctor?.account?.email}')),

                            ],),

                            // Row 2 for buttons 
                            Row(children: [

                                Expanded(flex:0, child: Text('ID: ${doctor?.id}')),
                              
                                // Aligns buttons to right 
                                const Spacer(),                          
                                
                                Expanded(flex: 0, child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    minimumSize: Size(20, 30)
                                  ),
                                  child: const Text('Edit'),
                                  onPressed: () => {
                                    edit(doctor?.id)
                                  }
                                ),),

                                // Adds 5px space between buttons 
                                const SizedBox(width: 5),

                                Expanded(flex: 0, child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    minimumSize: const Size(50, 30)
                                  ),
                                  child: const Text('Remove'),
                                    onPressed: () => {
                                      remove(doctor?.id),
                                    }
                                ),),

                              ],)

                        ],),

                  );

                }, separatorBuilder: (context, index) {
                  
              // Divider line 
              return const Divider(
                thickness: 0.5,
                height: 10.5,
              );
              
            }, itemCount: snapshot.data?.length ?? 0);
          },
        ),
      ),
    );
  }

  // Redirects to adding doctor page
  void addDoc() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NewDoctorSAdminScreen()
        )
        // Refreshes page after coming back from route page
    ).then((value) => {refreshList()});                         
  }

  // Edits doctrs profile
  void edit(int? id) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditDoctorsSAdminScreen(doctorsId: id!)
        )
        
        // Refreshes page after coming back from route page
    ).then((value) => {refreshList()});  
  }

  // Removes doctor from db
  void remove(int? id) {
    _sAdminController.deleteDoctor(id);
    refreshList();
    // Debug 
    // print(id);
  }

}

