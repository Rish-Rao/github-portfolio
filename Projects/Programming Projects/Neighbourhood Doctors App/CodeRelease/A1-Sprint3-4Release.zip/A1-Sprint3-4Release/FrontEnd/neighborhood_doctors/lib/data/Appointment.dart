import 'dart:ui';

class Appointment {
  int? patientsId;
  int? doctorsId;
  String? date;

  Appointment({this.patientsId, this.doctorsId, this.date});

  Appointment.fromJson(Map<String, dynamic> json) {
    patientsId = json['patientsId'];
    doctorsId = json['doctorsId'];
    date = json['date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['patientsId'] = this.patientsId;
    data['doctorsId'] = this.doctorsId;
    data['date'] = this.date;
    return data;
  }
}


class AppointmentList {
  String appointTime;
  String appointMonth;
  Color textColor;
  Color color;
  Color iconColor;
  String doctorType;
  String appointDate;

  AppointmentList(
      {required this.appointTime,
        required this.appointMonth,
        required this.textColor,
        required this.color,
        required this.iconColor,
        required this.doctorType,
        required this.appointDate});
}