import 'package:flutter/material.dart';
import 'package:neighborhood_doctors/controller/Controllers.dart';
import '../data/Models.dart';

class AddPrescriptionScreen extends StatelessWidget {
  const AddPrescriptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const appTitle = 'Add prescription';

    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(appTitle),
        ),
        body: const MyCustomForm(),
      ),
    );
  }
}

// Create a Form widget.
class MyCustomForm extends StatefulWidget {
  const MyCustomForm({super.key});

  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

class MyCustomFormState extends State<MyCustomForm> {

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _medicationNameController =
      TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _patientIdController = TextEditingController();

  Future<Prescription>? _futurePrescription;

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 45),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Align(
              alignment: Alignment.center,
              child: SizedBox(
                width: 300,
                child: TextFormField(
                  controller: _patientIdController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'patientId',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'patientId cannot be empty';
                    }
                    return null;
                  },
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: SizedBox(
                width: 300,
                child: TextFormField(
                  controller: _medicationNameController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'MedicationName',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Medication cannot be empty';
                    }
                    return null;
                  },
                ),
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: SizedBox(
                width: 300,
                child: TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Description',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Description cannot be empty';
                    }
                    return null;
                  },
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Processing Data')),
                  );
                }
                setState(() {
                  _futurePrescription = createPrescription(
                      _medicationNameController.text,
                      _descriptionController.text,
                      _patientIdController.text);
                });
              },
              child: const Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}
