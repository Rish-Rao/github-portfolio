import 'dart:convert';

import 'package:neighborhood_doctors/screens/Screens.dart';
import 'package:neighborhood_doctors/data/Models.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import "package:http/http.dart" as http;
import 'package:neighborhood_doctors/utils/CustomNavBar.dart';

class EmailFieldValidator {
  static String? validate(String value) {
    return value.isEmpty ? 'Email can\'t be empty' : null;
  }
}

class PasswordFieldValidator {
  static String? validate(String value) {
    return value.isEmpty ? 'Password can\'t be empty' : null;
  }
}


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginState();
}

class _LoginState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  User user = User("", "","","","",);

  String url = "http://10.0.2.2:8080/login";

  Future save() async {
    var res = await http.post(Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'email': user.email, 'password': user.password}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
            key: _formKey,
            child: Column(
              children: [
                Container(
                  height: 1000,
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 77, 136, 229),
                      boxShadow: [
                        BoxShadow(
                            blurRadius: 10,
                            color: Colors.black,
                            offset: Offset(1, 5)
                        )
                      ],

                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(22),
                          bottomRight: Radius.circular(22))
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(children: [
                      SizedBox(
                        height: 100,
                      ),
                      Text("Login",
                          style: GoogleFonts.alexBrush(
                            fontWeight: FontWeight.bold,
                            fontSize: 50,
                            color: Color.fromARGB(255, 253, 255, 255),

                          )),
                      SizedBox(height: 60,),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          "Email",
                          style: GoogleFonts.actor(
                            // fontWeight: FontWeight.bold,
                            fontSize: 30,
                            color: Color.fromRGBO(255, 255, 255, 0.8),
                          ),
                        ),
                      ),
                      TextFormField(
                        controller: TextEditingController(text: user.email),
                        onChanged: (val) {
                          user.email = val;
                        },
                        validator: (String ?value) {
                          if (value!.isEmpty) {
                            return "Email cannot be empty";
                          }
                          return null;
                        },
                        onSaved: (String? value) {
                          user.email = value!;
                        },
                        style: TextStyle(
                            fontSize: 30, color: Colors.white),
                        decoration: InputDecoration(
                            border: OutlineInputBorder(borderSide: BorderSide
                                .none)),
                      ),
                      Container(
                        height: 8,
                        color: Color.fromRGBO(255, 255, 255, 0.4),
                      ),
                      SizedBox(height: 30,),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          "Password",
                          style: GoogleFonts.actor(
                            fontSize: 30,
                            color: Color.fromRGBO(255, 255, 255, 0.8),
                          ),

                        ),
                      ),
                      TextFormField(
                        controller: TextEditingController(text: user.password),
                        onChanged: (val) {
                          user.password = val;
                        },
                        validator: (String ?value) {
                          if (value!.isEmpty) {
                            return "Password cannot be empty";
                          }
                          return null;
                        },
                        onSaved: (String? value) {
                          user.password = value!;
                        },                        
                        style: TextStyle(
                            fontSize: 30, color: Colors.white),
                        decoration: InputDecoration(
                            border: OutlineInputBorder(borderSide: BorderSide
                                .none)),
                      ),
                      Container(
                        height: 8,
                        color: Color.fromRGBO(255, 255, 255, 0.4),
                      ),
                      SizedBox(height: 60,
                      ),
                      Center(
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Register()));
                          },
                          child: Text("Don't have an account?",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.bold,
                                fontSize: 15, color: Colors.white),
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: ()=> {
                          if (_formKey.currentState!.validate()) {
                              _formKey.currentState?.save(),
                          },
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const CustomNavBar()),
                          ),
                        },
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white, // Text Color
                        ),
                        child: const Text("Login",
                          style: TextStyle(fontSize: 30),
                        ),
                      )
                    ],
                    ),
                  ),
                ),
              ],

            )
        ),
      ),
    );
  }
}