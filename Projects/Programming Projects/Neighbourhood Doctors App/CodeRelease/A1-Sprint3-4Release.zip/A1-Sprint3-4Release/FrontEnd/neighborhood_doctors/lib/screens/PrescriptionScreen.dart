import 'package:flutter/material.dart';
import 'package:neighborhood_doctors/controller/Controllers.dart';
import '../data/Models.dart';

class PrescriptionScreen extends StatefulWidget {
  const PrescriptionScreen({super.key});

  @override
  State<PrescriptionScreen> createState() => _PrescriptionScreenState();
}

class _PrescriptionScreenState extends State<PrescriptionScreen> {
  late Future<List<Prescription>> futureData;

  @override
  void initState() {
    super.initState();
    futureData = fetchPrescriptions();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter API and ListView Example',
      home: Scaffold(
        appBar: AppBar(
          title: Text('My prescriptions'),
        ),
        body: Center(
          child: FutureBuilder<List<Prescription>>(
            future: futureData,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                List<Prescription>? data = snapshot.data;
                return ListView.builder(
                    itemCount: data?.length,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                          height: 75,
                          color: Colors.white,
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(data![index].medicationName),
                              ),
                              Expanded(
                                child: Text(data[index].description),
                              ),
                            ],
                          ));
                    });
              } else if (snapshot.hasError) {
                return Text("${snapshot.error}");
              }
              // By default show a loading spinner.
              return CircularProgressIndicator();
            },
          ),
        ),
      ),
    );
  }
}
