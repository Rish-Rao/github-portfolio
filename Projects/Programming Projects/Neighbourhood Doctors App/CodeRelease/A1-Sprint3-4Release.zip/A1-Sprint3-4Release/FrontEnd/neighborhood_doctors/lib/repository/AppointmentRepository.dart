import 'package:neighborhood_doctors/data/doctor.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AppointmentRepository {

  // Change this for android and ios devices -- 
  // Uncomment First one if u are using android and commend the one below
  // If on Apple machine comment the first one out and uncomment the second one 

  // IOS Url 
  // final String dataURL = 'http://localhost:8080/appointment';
  // Android uses alias for local host as below 

  final String dataURL = 'http://10.0.2.2:8080/appointment';

  Future<List<Doctor>> getDoctorsList() async {
    List<Doctor> doctorList = [];
    
    var url = Uri.parse('$dataURL/doctors');
    
    var response = await http.get(url);
    // ignore_for_file: avoid_print
    print('status code : ${response.statusCode}');
    var body = json.decode(response.body); // convert

    //parse
    for (var i = 0; i < body.length; i++) {
      doctorList.add(Doctor.fromJson(body[i]));
    }
    return doctorList;
  }

}