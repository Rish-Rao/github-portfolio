import 'Account.dart';
import 'Appointment.dart';

class Doctor {
  int? id;
  String? firstName;
  String? lastName;
  Account? account;
  List<Appointment>? appointment;

  Doctor(
      {this.id, this.firstName, this.lastName, this.account, this.appointment});

  Doctor.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    account =
    json['account'] != null ? new Account.fromJson(json['account']) : null;
    if (json['appointment'] != null) {
      appointment = <Appointment>[];
      json['appointment'].forEach((v) {
        appointment!.add(new Appointment.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    if (this.account != null) {
      data['account'] = this.account!.toJson();
    }
    if (this.appointment != null) {
      data['appointment'] = this.appointment!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Doctors {
  String doctorName;
  String doctorType;
  String doctorLocation;
  int doctorExperience;
  int doctorPatients;
  String doctorAbout;
  String doctorImage;

  Doctors({
    required this.doctorName,
    required this.doctorType,
    required this.doctorLocation,
    required this.doctorExperience,
    required this.doctorPatients,
    required this.doctorAbout,
    required this.doctorImage,
  });
}


