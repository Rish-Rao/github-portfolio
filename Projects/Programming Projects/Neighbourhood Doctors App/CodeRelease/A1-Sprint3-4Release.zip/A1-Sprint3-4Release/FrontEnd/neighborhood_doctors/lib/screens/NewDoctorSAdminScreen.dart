/*
  Code Concept taken from - 
    https://www.youtube.com/watch?v=nFSL-CqwRDo
  and modified accroding to my preference 
*/

import 'package:flutter/material.dart';
import 'package:neighborhood_doctors/controller/Controllers.dart';
import 'package:neighborhood_doctors/repository/Repositories.dart';

class NewDoctorSAdminScreen extends StatefulWidget {
  
  @override
  State<NewDoctorSAdminScreen> createState() => _NewDoctorSAdminScreenStateful();

}

class _NewDoctorSAdminScreenStateful extends State<NewDoctorSAdminScreen> {

  final _sAdminController = SAdminController(SAdminRepository());
  final _formKey = GlobalKey<FormState>();

  late String _firstName;
  late String _lastName;
  late String _email;
  late String _password;

  Widget _buildFirstNameField() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'FirstName'),

      validator: (String? value) {
        if (value!.isEmpty) {
          return "FirstName cannot be empty";
        }
        return null;
      },
      
      onSaved: (String? value) {
        _firstName = value!;
      },

    );
  }

    Widget _buildLastNameField() {
      return TextFormField(
        decoration: InputDecoration(labelText: 'LastName'),

        validator: (String? value) {
          if (value!.isEmpty) {
            return "LastName cannot be empty";
          }
          return null;
        },
        
        onSaved: (String? value) {
          _lastName = value!;
        },

      );
  }

    Widget _buildEmailField() {
      return TextFormField(
        decoration: InputDecoration(labelText: 'Email'),
        keyboardType: TextInputType.emailAddress,

        validator: (String? value) {
          if (value!.isEmpty) {
            return "Email cannot be empty";
          }

          // Email regex
          if (!RegExp(
                r"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
            .hasMatch(value)) {
          return 'Please enter a valid email Address';
          }

          return null;
        },
        
        onSaved: (String? value) {
          _email = value!;
        },

      );
  }

    Widget _buildPasswordField() {
      return TextFormField(
        decoration: InputDecoration(labelText: 'Password'),
        keyboardType: TextInputType.visiblePassword,

        validator: (String? value) {
          if (value!.isEmpty) {
            return "Password is required";
          }

          return null;
        },
        
        onSaved: (String? value) {
          _password = value!;
        },

      );
  }



  @override
  Widget build(BuildContext context) {

    return Scaffold(
      
      // App Bar
      appBar: AppBar(
        title: const Text('Add Doctor'),
      ),


      // Container
      body: Container(

        // Sort of all sides padding 
        margin: EdgeInsets.all(42),

        // Form
        child: Form(
          key: _formKey,
          child: Column(
            
            // Everything in center
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              _buildFirstNameField(),
              _buildLastNameField(),
              SizedBox(height: 20,),
              _buildEmailField(),
              _buildPasswordField(),

              // Button
              SizedBox(height: 40,),
              ElevatedButton(
                child: const Text('Add'),

                // On Click event 
                onPressed: () => {
            
                  if(_formKey.currentState!.validate()) {
                     _formKey.currentState?.save(),
                     createDoctor()
                  } 

                },
              )

            ],

          ),
        )

      ),


    );
  }

  // Creates a new doctor
  Future<void> createDoctor() async {
    int accountId = await _sAdminController.createAccount(_email, _password);

    if(accountId > 0) {
      _sAdminController.createDoctor(_firstName, _lastName, accountId);

      // Takes back to doctors list page 
      Navigator.pop(context);
    }   
  }

}