import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:async';
import '../data/Models.dart';
// 
Future<List<Prescription>> fetchPrescriptions() async {
  String patientId = '1';
  final response = await http.get(
      Uri.parse('http://localhost:8080/prescription/$patientId/prescriptions'));
  if (response.statusCode == 200) {
    List jsonResponse = json.decode(response.body);
    return jsonResponse.map((data) => Prescription.fromJson(data)).toList();
  } else {
    throw Exception('Unexpected error occured!');
  }
}

Future<Prescription> createPrescription(
    String medicationName, String description, String patientId) async {
  final response = await http.post(
    Uri.parse('http://localhost:8080/prescription/prescription'),
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
    body: jsonEncode(<String, String>{
      'id': '1',
      'medicationName': medicationName,
      'description': description,
      'doctorId': '3',
      'patientId': patientId
    }),
  );

  if (response.statusCode == 201) {
    // If the server did return a 201 CREATED response,
    // then parse the JSON.
    return Prescription.fromJson(jsonDecode(response.body));
  } else {
    // If the server did not return a 201 CREATED response,
    // then throw an exception.
    throw Exception('Failed to create prescription.');
  }
}
