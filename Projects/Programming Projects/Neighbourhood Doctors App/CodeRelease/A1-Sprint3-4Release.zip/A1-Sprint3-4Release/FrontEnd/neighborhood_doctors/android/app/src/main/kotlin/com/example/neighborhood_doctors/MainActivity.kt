package com.example.neighborhood_doctors

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
