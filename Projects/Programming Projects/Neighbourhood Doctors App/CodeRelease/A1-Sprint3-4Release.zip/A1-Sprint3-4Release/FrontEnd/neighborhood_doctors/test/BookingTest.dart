// import 'package:flutter_test/flutter_test.dart';
// import 'package:neighborhood_doctors/controller/AppointmentController.dart';
// import 'package:neighborhood_doctors/repository/AppointmentRepository.dart';
// import 'package:http/http.dart' as http;

// void main() {

//   // test('able to fetch data', () async {

//   //   Uri dataURL = Uri.parse('http://localhost:8080/appointment');
//   //   final response = await http.get(dataURL);

//   //   print("Values ::: ");
//   //   print(response);
//   //   expect(response, 200);

//   // });


// }