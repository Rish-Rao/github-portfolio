class Prescription {
  final int id;
  final int patientId;
  final int doctorId;
  final String medicationName;
  final String description;

  const Prescription(
      {required this.id,
      required this.patientId,
      required this.medicationName,
      required this.doctorId,
      required this.description});

  factory Prescription.fromJson(Map<String, dynamic> json) {
    return Prescription(
        id: json['id'],
        patientId: json['patientId'],
        doctorId: json['doctorId'],
        medicationName: json['medicationName'],
        description: json['description']);
  }

  toJson() {
    return {
      'id': id,
      'medicationName': medicationName,
      'patientId': patientId,
      'doctorId': doctorId,
      'description': description
    };
  }
}
