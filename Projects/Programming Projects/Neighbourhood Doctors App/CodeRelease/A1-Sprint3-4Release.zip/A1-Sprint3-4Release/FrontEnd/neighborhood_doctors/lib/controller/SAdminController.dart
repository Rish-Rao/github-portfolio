import 'package:neighborhood_doctors/data/Models.dart';
import 'package:neighborhood_doctors/repository/Repositories.dart';
import 'package:http/http.dart' as http;

class SAdminController {
  final SAdminRepository sAdminRepository;

  SAdminController(this.sAdminRepository);

  //get 
  Future<List<Doctor>> fetchDoctorsList() async {
    return sAdminRepository.getDoctorsList();
  }

  // get account id 
  Future<int> getDoctorsAccountId(int id) async {
    return sAdminRepository.getDoctorsAccountId(id);
  } 

  //delete
  Future<http.Response> deleteDoctor(int? id) async {
    return sAdminRepository.deleteDoctor(id);
  }

  //post
  Future<int> createAccount(String email, String password) async {
    return sAdminRepository.createAccount(email, password);
  }

  //post
  Future<http.Response> createDoctor(String firstName, String lastName, int accountId) async {
    return sAdminRepository.createDoctor(firstName, lastName, accountId);
  }

  //put
  Future<http.Response> putDoctor(String firstName, String lastName, int doctorsId) async {
    return sAdminRepository.putDoctor(firstName, lastName, doctorsId);
  }

  //put
  Future<http.Response> putAccount(String email, String password, int accountId) async {
    return sAdminRepository.putAccount(email, password, accountId);
  }
  
}