import 'Account.dart';

class User{
  String? id;
  String? firstName;
  String? lastName;
  String? email;
  String? password;
  // Account? account;
  User(this.id, this.email, this.password, this.firstName, this.lastName);

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    email = json['email'];
    password = json['password'];
    // account =
    // json['account'] != null ? new Account.fromJson(json['account']) : null;

  }

    Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    // if (this.account != null) {
    //   data['account'] = this.account!.toJson();
    // }
    return data;
  }

}









