import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import "package:http/http.dart" as http;
import 'package:neighborhood_doctors/controller/Controllers.dart';
import 'package:neighborhood_doctors/repository/Repositories.dart';
import 'package:neighborhood_doctors/utils/CustomNavBar.dart';


class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);



  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final _registerController = RegisterController(RegisterRepository());

  final _formKey = GlobalKey<FormState>();
  late String firstName = "";
  late String lastName ="";
  late String email ="";
  late String password = "";

  String url = "http://10.0.2.2:8080/register";

  Future save() async {
    // var res = await http.post(url,
    var res = await http.post(Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'firstName': firstName, 'lastName':lastName, 'email': email, 'password': password}));
    print(res.body);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
            key: _formKey,
            child: Column(
              children: [
                Container(
                  height: 1000,
                  width: MediaQuery
                      .of(context)
                      .size
                      .width,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 77, 136, 229),
                      boxShadow: [
                        BoxShadow(
                            blurRadius: 10,
                            color: Colors.black,
                            offset: Offset(1, 5)
                        )
                      ],

                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(22),
                          bottomRight: Radius.circular(22))
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(children: [
                      SizedBox(
                        height: 50,
                      ),
                      Text("Register",
                          style: GoogleFonts.alexBrush(
                            fontWeight: FontWeight.bold,
                            fontSize: 50,
                            color: Color.fromARGB(255, 253, 255, 255),

                          )),
                        // firstname box
                                              SizedBox(height: 20,),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          "First name",
                          style: GoogleFonts.actor(
                            // fontWeight: FontWeight.bold,
                            fontSize: 30,
                            color: Color.fromRGBO(255, 255, 255, 0.8),
                          ),
                        ),
                      ),
                      TextFormField(
                        controller: TextEditingController(text: firstName),
                        onChanged: (val) {
                          firstName = val;
                        },
                        validator: (String ?value) {
                          if (value!.isEmpty) {
                            return "First name cannot be empty";
                          }
                          return null;
                        },
                        style: TextStyle(
                            fontSize: 30, color: Colors.white),
                        decoration: InputDecoration(
                            border: OutlineInputBorder(borderSide: BorderSide
                                .none)),
                      ),
                      Container(
                        height: 8,
                        color: Color.fromRGBO(255, 255, 255, 0.4),
                      ),

                      // lastname box

                      SizedBox(height: 20,),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          "Last name",
                          style: GoogleFonts.actor(
                            // fontWeight: FontWeight.bold,
                            fontSize: 30,
                            color: Color.fromRGBO(255, 255, 255, 0.8),
                          ),
                        ),
                      ),
                      TextFormField(
                        controller: TextEditingController(text: lastName),
                        onChanged: (val) {
                          lastName = val;
                        },
                        validator: (String ?value) {
                          if (value!.isEmpty) {
                            return "Last name cannot be empty";
                          }
                          return null;
                        },
                        style: TextStyle(
                            fontSize: 30, color: Colors.white),
                        decoration: InputDecoration(
                            border: OutlineInputBorder(borderSide: BorderSide
                                .none)),
                      ),
                      Container(
                        height: 8,
                        color: Color.fromRGBO(255, 255, 255, 0.4),
                      ),

                          // email box
                      SizedBox(height: 20,),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          "Email",
                          style: GoogleFonts.actor(
                            // fontWeight: FontWeight.bold,
                            fontSize: 30,
                            color: Color.fromRGBO(255, 255, 255, 0.8),
                          ),
                        ),
                      ),
                      TextFormField(
                        controller: TextEditingController(text: email),
                        onChanged: (val) {
                          email = val;
                        },
                        validator: (String ?value) {
                          if (value!.isEmpty) {
                            return "Email cannot be empty";
                          }
                          // Email regex
                          if (!RegExp(
                                r"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
                            .hasMatch(value)) {
                          return 'Please enter a valid email Address';
                          }
                          return null;
                        },
                          onSaved: (String? value) {
                          email = value!;
                        },
                        style: TextStyle(
                            fontSize: 30, color: Colors.white),
                        decoration: InputDecoration(
                            border: OutlineInputBorder(borderSide: BorderSide
                                .none)),
                      ),
                      Container(
                        height: 8,
                        color: Color.fromRGBO(255, 255, 255, 0.4),
                      ),


                      // password box
                      SizedBox(height: 20,),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          "Password",
                          style: GoogleFonts.actor(
                            // fontWeight: FontWeight.bold,
                            fontSize: 30,
                            color: Color.fromRGBO(255, 255, 255, 0.8),
                          ),

                        ),
                      ),
                      TextFormField(
                        controller: TextEditingController(text: password),
                        onChanged: (val) {
                          password = val;
                        },
                        validator: (String ?value) {
                          if (value!.isEmpty) {
                            return "Password cannot be empty";
                          }
                          return null;
                        },
                        onSaved: (String? value) {
                        password = value!;
                      },
                        style: TextStyle(
                            fontSize: 30, color: Colors.white),
                        decoration: InputDecoration(
                            border: OutlineInputBorder(borderSide: BorderSide
                                .none)),
                      ),
                      Container(
                        height: 8,
                        color: Color.fromRGBO(255, 255, 255, 0.4),
                      ),
                      SizedBox(height: 60,
                      ),
                      Center(
                        child: InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Text("Already have an account?",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.bold,
                                fontSize: 15, color: Colors.white),
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: ()  =>{
                          if (_formKey.currentState!.validate()) {
                               _formKey.currentState?.save(),
                                createUser()
                  },
                          
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const CustomNavBar()),
                                    ),
                        },
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white, // Text Color
                        ),
                        child: const Text("Register",
                          style: TextStyle(fontSize: 30),

                        ),
                      )
                    ],
                    ),
                  ),
                ),
              ],

            )
        ),
      ),
    );
  }

    Future<void> createUser() async {
    int accountId = await _registerController.createAccount(email, password);

    if(accountId > 0) {
      _registerController.createUser(firstName, lastName, accountId);
    }
    }
}