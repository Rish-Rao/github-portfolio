
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:neighborhood_doctors/data/Models.dart';

class SAdminRepository {

  final _usrType = "doctor";

  // Change this for android and ios devices -- 
  // Uncomment First one if u are using android and commend the one below
  // If on Apple machine comment the first one out and uncomment the second one 

  // IOS Url 
  // final _dataURL = 'http://localhost:8080/sAdmin';
  // Android uses alias for local host as below 
  final _dataURL = 'http://10.0.2.2:8080/sAdmin';

  // Returns list of all doctors
  Future<List<Doctor>> getDoctorsList() async {
    List<Doctor> doctorList = [];
    
    final url = Uri.parse('$_dataURL/doctors');
    
    final response = await http.get(url);

    var body = json.decode(response.body); // convert

    //parse
    for (var i = 0; i < body.length; i++) {
      doctorList.add(Doctor.fromJson(body[i]));
    }

    return doctorList;
  } 

  // Return account id by taking in doctors id 
  Future<int> getDoctorsAccountId(int id) async {
  
    var url = Uri.parse('$_dataURL/doctor/account/$id');
    var response = await http.get(url);

    int accountId = json.decode(response.body); // convert

    return accountId;
  }


  // Deletes doctor with theit id
  Future<http.Response> deleteDoctor(int? id) async {
    var url = Uri.parse('$_dataURL/doctor/$id');
    var response = await http.delete(url);
    return response;
  }

  // Creates new account and returns account id 
  Future<int> createAccount(String email, String password) async {
    var url = Uri.parse('$_dataURL/account');
    
    // json body
    var body = jsonEncode({
      "email": email,
      "passwordHash": password,
      "userType": _usrType
    });

    var response = await http.post
      (
        url,
        headers: {"Content-Type": "application/json"},
        body: body
      );

    int accountId = json.decode(response.body); // convert

    return accountId;
  }

  // Create a new doctors with account id 
  Future<http.Response> createDoctor(String firstName, String lastName, int accountId) async {
    var url = Uri.parse('$_dataURL/doctor/$accountId');
    
    // json body
    var body = jsonEncode({
      "firstName": firstName,
      "lastName": lastName,
    });

    var response = await http.post
      (
        url,
        headers: {"Content-Type": "application/json"},
        body: body
      );

    return response;
  }

  // Edits doctors details 
  Future<http.Response> putDoctor(String firstName, String lastName, int doctorsId) async {
    var url = Uri.parse('$_dataURL/doctor/$doctorsId');
    
    // json body
    var body = jsonEncode({
      "firstName": firstName,
      "lastName": lastName,
    });

    var response = await http.put
      (
        url,
        headers: {"Content-Type": "application/json"},
        body: body
      );

    return response;
  }
  
  // Edits doctors account details 
  Future<http.Response> putAccount(String email, String password, int accountId) async {
    var url = Uri.parse('$_dataURL/account/$accountId');
    
    // json body
    var body = jsonEncode({
      "email": email,
      "passwordHash": password,
    });

    var response = await http.put
      (
        url,
        headers: {"Content-Type": "application/json"},
        body: body
      );

    return response;
  }

  




}