class Account {
  int? id;
  String? email;
  String? passwordHash;
  String? userType;

  Account({this.id, this.email, this.passwordHash, this.userType});

  Account.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    passwordHash = json['passwordHash'];
    userType = json['userType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['email'] = this.email;
    data['passwordHash'] = this.passwordHash;
    data['userType'] = this.userType;
    return data;
  }
}