import 'package:neighborhood_doctors/data/doctor.dart';
import 'package:neighborhood_doctors/repository/Repositories.dart';

class AppointmentController {
  final AppointmentRepository appointmentRepository;

  AppointmentController(this.appointmentRepository);

  //get 
  Future<List<Doctor>> fetchDoctorsList() async {
    return appointmentRepository.getDoctorsList();
  }
}