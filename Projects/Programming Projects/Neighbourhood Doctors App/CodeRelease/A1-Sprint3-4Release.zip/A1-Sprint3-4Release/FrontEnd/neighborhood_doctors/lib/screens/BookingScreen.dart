import 'package:flutter/material.dart';
import 'package:neighborhood_doctors/controller/Controllers.dart';
import 'package:neighborhood_doctors/data/doctor.dart';
import 'package:neighborhood_doctors/repository/Repositories.dart';

class BookingScreen extends StatelessWidget {
  const BookingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // dependency injection
    var appointmentController = AppointmentController(AppointmentRepository());


    return Scaffold(
      appBar: AppBar(
        title: const Text('Booking'),
      ),
      body: FutureBuilder<List<Doctor>>(
        future: appointmentController.fetchDoctorsList(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(
              child: Text('Could not fetch data'),
            );
          }

          return ListView.separated(
              itemBuilder: (context, index) {
                var doctor = snapshot.data?[index];
                return Container(
                    height: 100.0,
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Row(
                      children: [
                        Expanded(flex: 1, child: Text('Id: ${doctor?.id}')),
                        Expanded(flex: 2, child: Text('${doctor?.firstName}')),
                        Expanded(flex: 2, child: Text('${doctor?.lastName}')),
                        Expanded(flex: 3, child: Text('${doctor?.account
                            ?.email}')),
                      ],
                    )
                );
              }, separatorBuilder: (context, index) {
            return Divider(
              thickness: 0.5,
              height: 0.5,
            );
          }, itemCount: snapshot.data?.length ?? 0);
        },
      ),
    );
  }

}
